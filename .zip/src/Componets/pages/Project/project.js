import React from "react";

function ProjectM () {
    return(
        <div>
            <h1>this is project Management tab</h1>
        </div>
    )
}

export default ProjectM;